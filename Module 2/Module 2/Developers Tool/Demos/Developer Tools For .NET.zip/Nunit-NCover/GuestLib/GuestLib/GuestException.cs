using System;
using System.Collections.Generic;
using System.Text;

namespace GuestLib
{
    public class GuestException : Exception
    {
        public GuestException()
            : base()
        {

        }

        public GuestException(string msg)
            : base(msg)
        {

        }
    }
}
