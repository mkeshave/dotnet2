using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using GuestLib;
using NUnit.Framework.SyntaxHelpers;

namespace GuestTest
{
    [TestFixture]
    public class GuestTest
    {
        private Guest guest = null;

        [SetUp]
        public void SetUp()
        {
            guest = new Guest();
        }

        [Test]
        public void Test01()
        {
            guest.GuestID = 101;
            Assert.AreEqual(101, guest.GuestID);
        }

        [Test]
        public void Test02()
        {
            guest.GuestName = "Karthik";
            Assert.AreEqual("Karthik", guest.GuestName);
        }

        [Test]
        public void Test03()
        {
            guest.PhoneNumber = "9841701459";
            Assert.AreEqual("9841701459", guest.PhoneNumber);
        }

        [Test]
        public void Test04()
        {
            guest.Title = Salutation.Mr;
            Assert.AreEqual(Salutation.Mr, guest.Title);
        }

        [Test]
        public void Test05()
        {
            List<Guest> guestList=new List<Guest>();
            guestList.Add(new Guest(101,Salutation.Mr,"Karthik","9841701459"));
            guest.Guests = guestList;
            Assert.That(guest.Guests.Count, Is.EqualTo(1));
        }


        [TearDown]
        public void TearDown()
        {
            guest = null;
        }

    }
}
