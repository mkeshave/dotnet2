using System;
using System.Collections.Generic;
using System.Text;
using Demo04;
using NUnit.Framework;

namespace Demo04Test
{
    public class SampleDerive:Sample
    {
        public int CallAddNos(int a,int b)
        {
            return AddNos(a, b);
        }
    }

    [TestFixture]
    public class SampleTest
    {
        SampleDerive derive = null;

        [SetUp]
        public void TestInitialize()
        {
            derive = new SampleDerive();
        }

        [Test]
        public void Test01()
        {
            int actual = derive.CallAddNos(5, 4);
           
            int expected = 9;
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void Test02()
        {
            int actual = Sample.MultiplyNos(6, 7);

            int expected = 42;
            Assert.AreEqual(expected, actual);
        }

        [TearDown]
        public void TestCleanUp()
        {
            derive = null;
        }
    }
}
