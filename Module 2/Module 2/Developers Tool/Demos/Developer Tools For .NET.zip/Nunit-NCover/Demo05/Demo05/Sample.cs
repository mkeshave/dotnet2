using System;
using System.Collections.Generic;
using System.Text;

namespace Demo05
{
    /// <summary>
    /// Testing Private Variables and Methods
    /// </summary>
    
    public class Sample
    {
        private int testNo = 7;

        private int AddNos(int a,int b)
        {
            return a + b;
        }

        public Sample()
        {
 
        }
    }
}
