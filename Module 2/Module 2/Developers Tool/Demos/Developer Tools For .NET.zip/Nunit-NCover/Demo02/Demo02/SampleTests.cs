using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using System.Collections;
using NUnit.Framework.SyntaxHelpers;
using System.IO;
using NUnit.Framework.Constraints;

namespace Demo02
{

    #region Employee Class
    public class Employee
    {
        private int empID;

        public int EmpID
        {
            get { return empID; }
            set { empID = value; }
        }

        private string companyName = "iGate";

        public string CompanyName
        {
            get { return companyName; }

        }

    }
    #endregion

    [TestFixture]
    public class SampleTests : AssertionHelper
    {
        [Test]
        public void EqualityAsserts()
        {
            Assert.AreEqual(5.4, 5.4);
        }

        [Test]
        public void IdentityAsserts()
        {
            string name = "Novendu";
            string name1 = "Karthik";
            Assert.AreSame(name.GetType(), name1.GetType());
        }

        [Test]
        public void ComparsionAssert()
        {
            Assert.Greater(51, 39);
            Assert.Less(34, 65);
        }

        [Test]
        public void TypeAsserts()
        {
            int num = 5;
            Assert.IsInstanceOfType(typeof(int), num);
        }

        [Test]
        public void ConditionTests()
        {
            bool res = true;
            string s = string.Empty;
            string nullstring = null;

            Assert.IsTrue(res);
            Assert.IsEmpty(s);
            Assert.IsNull(nullstring);

        }

        [Test]
        public void Utitlity()
        {
            //Assert.True();
            // Assert.Fail();
            //Assert.Ignore();

        }


        [Test]
        public void StringAssert()
        {
            string companyName = "iGate Global Solutions";
            NUnit.Framework.StringAssert.Contains("Global", companyName);
        }

        [Test]
        public void CollectionAssert()
        {
            ArrayList list = new ArrayList();
            list.Add("iGate");
            list.Add("Microsoft");
            list.Add("oracle");


            NUnit.Framework.CollectionAssert.Contains(list, "iGate");

            Assert.That(list, Is.Unique);
        }


        [Test]
        public void FileAssert()
        {
            FileStream fs1 = new FileStream(@"d:\cursors.txt", FileMode.Open, FileAccess.Read);
            FileStream fs2 = new FileStream(@"d:\cursors.txt", FileMode.Open, FileAccess.Read);
            NUnit.Framework.FileAssert.AreEqual(fs1, fs2);

        }

        [Test]
        public void AssertThat()
        {
            string companyName = "iGate";
            Exception ex1 = new Exception();
            Exception ex2 = ex1;

            Assert.That(2 + 2, Is.EqualTo(4));
            Assert.That(2 + 2 == 4);
            Assert.That(2 + 2, Is.Not.EqualTo(5));
            Assert.That(2 + 2 != 5);
            Assert.That(5.0, Is.EqualTo(5));


            Assert.That(companyName, Is.EqualTo("iGate"));

            Assert.That(companyName, new EqualConstraint("iGate"));

            Assert.That(ex2, Is.SameAs(ex1));


        }

        [Test]
        public void AssertThatinCollections()
        {
            ArrayList list = new ArrayList();
            list.Add("iGate");
            list.Add("Microsoft");
            list.Add("Oracle");


           // Assert.That(list, Is.Unique);
             Assert.That(list, Is.Not.Empty);
        }

        [Test]
        public void ComparisonConstraints()
        {
            int expected = 5;
            Assert.That(expected, Is.GreaterThan(3));
        }

        [Test]
        public void ExpectMethod()
        {
            //If you derive your test fixture class from AssertionHelper, the Expect() method may be used in place of Assert.That()

            string companyName = "iGate";
            Expect(companyName, new EqualConstraint("iGate"));
        }

        [Test]
        public void TypeConstraints()
        {
            Assert.That("iGate", Is.TypeOf(typeof(string)));
            Assert.That("iGate", Is.Not.TypeOf(typeof(int)));
            Assert.That("iGate", Is.InstanceOfType(typeof(object)));
            Assert.That(5, Is.Not.InstanceOfType(typeof(string)));
        }

        [Test]
        public void StringConstraints()
        {
            string phrase = "Make your tests fail before passing!";
            Assert.That(phrase, Text.Contains("tests fail"));
            Assert.That(phrase, Text.Contains("make").IgnoreCase);
            Assert.That(phrase, Text.StartsWith("Make"));
            Assert.That(phrase, Text.DoesNotStartWith("Break"));
        }

        [Test]
        public void CollectionConstraints()
        {

            ArrayList list = new ArrayList();
            list.Add("iGate");
            list.Add("Microsoft");
            list.Add("Oracle");
            //list.Add(7);

            Assert.That(list, Has.All.TypeOf(typeof(string)));


        }

        [Test]
        public void PropertyConstraint()
        {
            Employee emp = new Employee();
            Assert.That(emp, Has.Property("EmpID"));
            Assert.That(emp, Has.Property("CompanyName", "iGate"));


        }

    }

 
}
