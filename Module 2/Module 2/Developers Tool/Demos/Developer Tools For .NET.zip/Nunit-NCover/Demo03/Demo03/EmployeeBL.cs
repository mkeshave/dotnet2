using System;
using System.Collections.Generic;
using System.Text;

namespace Demo03
{
    public class EmployeeBL
    {
        private Employee employee = null;

      /*  public EmployeeBL(Employee employee)
        {
            this.employee = employee;
        }*/

        public List<Employee> GetAllEmployees()
        {
            return employee.GetAllEmployees();
        }

        public Employee GetEmployeeByID(int employeeID)
        {
            return employee.GetEmployeeByID(employeeID);
        }
    }
}
