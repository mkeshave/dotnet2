using System;
using System.Collections.Generic;
using System.Text;

namespace Demo03
{
    public interface IEmployee
    {
        /// <summary>
        /// Gets all employees.
        /// </summary>
        /// <returns>List of Employees</returns>
        List<Employee> GetAllEmployees();

        /// <summary>
        /// Gets the employee by ID.
        /// </summary>
        /// <param name="employeeID">The employee ID.</param>
        /// <returns>Employee</returns>
         Employee GetEmployeeByID(int employeeID);
    }
}
