using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Mocks;
using NUnit.Framework;
using Demo03;

namespace EmployeeTest
{
    [TestFixture]
    public class EmployeeBLTest
    {
        private DynamicMock employeeBLMock;
        private List<Employee> empList;
        private Employee employee1;
        private Employee employee2;


        [SetUp]
        public void Test01()
        {
            empList = new List<Employee>();
            employee1 = new Employee(1, "Karthik");
            employee2 = new Employee(2, "Novendu");
            empList.Add(employee1);
            empList.Add(employee2);
            employeeBLMock = new DynamicMock(Employee);
        }

        [Test]
        public void Test02()
        {
            employeeBLMock.ExpectAndReturn("GetAllEmployees", empList);
            EmployeeBL empObj = new EmployeeBL((Employee)employeeBLMock.MockInstance);
            Assert.AreEqual(2, empObj.GetAllEmployees().Count);
        }

        [Test]
        public void Test03()
        {
            employeeBLMock.ExpectAndReturn("GetEmployeeByID", employee2,1);
            EmployeeBL empBL = new EmployeeBL((Employee)employeeBLMock.MockInstance);
            Employee searchEmployee = empBL.GetEmployeeByID(1);
            Assert.AreEqual("Karthik", searchEmployee.EmployeeName);
            employeeBLMock.Verify();
        }
    }
}
